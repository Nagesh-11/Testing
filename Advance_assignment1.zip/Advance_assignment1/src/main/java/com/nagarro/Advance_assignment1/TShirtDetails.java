package com.nagarro.Advance_assignment1;

public class TShirtDetails {

	private String id,name,colour,gender,size,availability;
	private float price,rating;
	public TShirtDetails(String id, String name, String colour, String gender, String size,float price, float rating, String availability) 
	{
		
		this.id = id;
		this.name = name;
		this.colour = colour;
		this.gender = gender;
		this.size = size;
		this.availability = availability;
		this.price = price;
		this.rating = rating;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "TShirtDetails [id=" + id + ", name=" + name + ", colour=" + colour + ", gender=" + gender + ", size="
				+ size + ", availability=" + availability + ", price=" + price + ", rating=" + rating + "]";
	}
	
	
}


