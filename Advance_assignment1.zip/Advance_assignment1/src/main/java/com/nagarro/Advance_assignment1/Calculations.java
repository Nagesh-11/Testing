package com.nagarro.Advance_assignment1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.opencsv.exceptions.CsvValidationException;

public class Calculations {
	String preference;
	public Calculations(String preference) {
		super();
		this.preference = preference;
	}
	ArrayList<TShirtDetails> al=new ArrayList<>();

    public void TShirtReaderMethod(String filePath,String colour,String gender,String size) {
        try {
            FileReader fileReader = new FileReader(filePath);
            TShirtReader csvReader = new TShirtReader(fileReader);
            
            String[] line;
            while ((line = csvReader.readNext()) != null) {

            	if(line[3].equalsIgnoreCase(gender) && line[2].equalsIgnoreCase(colour) && line[4].equalsIgnoreCase(size)) {

            		TShirtDetails pd= new TShirtDetails(line[0], line[1], line[2], line[3], line[4], Float.parseFloat(line[5]), Float.parseFloat(line[6]), line[7]);
            			al.add(pd);
            	}
            	}
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
    public void print(String preference) {
    	if(preference.equalsIgnoreCase("rating")) {
    	Collections.sort(al, new Comparator<TShirtDetails>() {

			@Override
			public int compare(TShirtDetails o1, TShirtDetails o2) {
				// TODO Auto-generated method stub
				return Float.compare(o2.getRating(), o1.getRating());
			}
		});
    	}else if(preference.equalsIgnoreCase("price")) {
    		Collections.sort(al, new Comparator<TShirtDetails>() {
                 @Override
    			public int compare(TShirtDetails o1, TShirtDetails o2) {
    				// TODO Auto-generated method stub
    				return Float.compare(o1.getPrice(), o2.getPrice());
    			}
    		});
    	}
    	for(TShirtDetails b : al) {
        	System.out.println(b);
        }
    }

	public void run() {
		print(preference);
		
	}

	public void TShirtReader(String string, String colour, String gender, String size) {
		// TODO Auto-generated method stub
		
	}

	
	


}
