package com.nagarro.Advance_assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class TShirtReader {
	    public TShirtReader(FileReader fileReader) {
		// TODO Auto-generated constructor stub
	}
public static void main(String[] args) throws FileNotFoundException {
	    	Scanner sc=new Scanner(System.in);
	    	System.out.println("enter color");
	    	String colour=sc.next();
	    	System.out.println("enter gender");
	    	String gender=sc.next();
	    	System.out.println("enter size");
	    	String size=sc.next();
	    	System.out.println("enter sorting field price or rating ");
	    	String preference=sc.next();
	    	String filePath = new File("").getAbsolutePath() + File.separator + "src/main/resources/";
	        File fn=new File(filePath);
	         
	        Calculations ca=new Calculations(preference);
	        Thread t1= new Thread((Runnable) ca);
	        System.out.println("*Read via csv*");
	        for(File fileName:fn.listFiles()) {
	        	ca.TShirtReader(filePath+fileName.getName(),colour,gender,size);        	
	        }
	        t1.start();
	       }

		public String[] readNext() {
			// TODO Auto-generated method stub
			return null;
		}
		
		}
	



